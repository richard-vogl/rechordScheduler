package at.rich.recordScheduler.scheduler.timeTable;

import javax.swing.JComponent;

public class BroadcastDateComponent extends JComponent{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5999017386175647073L;

	public BroadcastDateComponent(){
		
	}
	
	
}
